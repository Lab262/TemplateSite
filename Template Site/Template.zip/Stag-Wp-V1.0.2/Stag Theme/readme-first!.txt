Thank you for using Stag theme for your project. 

As you can see, there are 2 .zip archives in this folder. 
The main theme is in "stag.zip". This is the theme you want to install.

If you want to use a child theme too along with the main theme, firstly install "stag.zip" and then install stag-child.zip" too. For more informations about child themes, visit http://codex.wordpress.org/Child_Themes

Thank you!