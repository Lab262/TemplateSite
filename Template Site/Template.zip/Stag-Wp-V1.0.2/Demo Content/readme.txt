This folder contains the files for importing the demo content.
As a suggestion, I recommend you import only "STAG-ALL-CONTENT.XML"

If you don`t want to import all the content, you can use the rest of the files from "Individual Import Files" to import separate sections, like projects. 

Thank you!

